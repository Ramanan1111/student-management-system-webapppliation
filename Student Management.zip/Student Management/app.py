from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"  # for flash messages

# MySQL Configuration
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "2003",
    "database": "student_db"
}

# Utility function to create DB connection
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# Detect if course is UG or PG
def detect_level(course_name):
    if course_name.upper().startswith(("B", "BE", "BSC", "BA")):
        return "UG"
    else:
        return "PG"

# ------------------------------
# HOME PAGE - List students & courses
# ------------------------------
@app.route("/")
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Search by ID
    q = request.args.get("q", "").strip()
    students = []
    if q:
        if q.isdigit():
            cursor.execute("SELECT * FROM students WHERE id=%s", (q,))
            students = cursor.fetchall()
        else:
            flash("Please enter a numeric ID to search.", "warning")
    else:
        cursor.execute("SELECT * FROM students ORDER BY id DESC")
        students = cursor.fetchall()

    cursor.close()
    conn.close()

    # List all course folders dynamically
    template_dir = "templates"
    ug_courses = []
    pg_courses = []

    for name in os.listdir(template_dir):
        path = os.path.join(template_dir, name)
        if os.path.isdir(path) and "index.html" in os.listdir(path):
            level = detect_level(name.replace("_", " "))
            if level == "UG":
                ug_courses.append(name)
            else:
                pg_courses.append(name)

    ug_courses.sort()
    pg_courses.sort()

    return render_template("index.html", students=students, q=q, ug_courses=ug_courses, pg_courses=pg_courses)

# ------------------------------
# ADD STUDENT
# ------------------------------
@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        Id = request.form['id']
        fname = request.form['first_name']
        lname = request.form['last_name']
        email = request.form['email']
        phone = request.form['phone']
        course = request.form['course'].strip()
        course_folder_name = course.replace(" ", "_")

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO students (id, first_name, last_name, email, phone, course) VALUES (%s,%s,%s,%s,%s,%s)",
                (Id, fname, lname, email, phone, course)
            )
            conn.commit()
            flash("Student added successfully!", "success")

            # Create course folder if not exists
            folder_path = os.path.join("templates", course_folder_name)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)

            # Create index.html inside course folder
            index_file = os.path.join(folder_path, "index.html")
            if not os.path.exists(index_file):
                with open(index_file, "w") as f:
                    f.write(f"""<!DOCTYPE html>
<html>
<head>
    <title>{course} Students</title>
    <link rel="stylesheet" href="{{{{ url_for('static', filename='style.css') }}}}">
</head>
<body>
    <h1>{course} Students</h1>
    <form method="get" action="">
        <input type="text" name="q" placeholder="Search by Student ID..." value="{{{{ q }}}}">
        <button type="submit">Search</button>
    </form>
    {{% if students %}}
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Phone</th>
        </tr>
        {{% for s in students %}}
        <tr>
            <td>{{{{ s.id }}}}</td>
            <td>{{{{ s.first_name }}}}</td>
            <td>{{{{ s.last_name }}}}</td>
            <td>{{{{ s.email }}}}</td>
            <td>{{{{ s.phone }}}}</td>
        </tr>
        {{% endfor %}}
    </table>
    {{% else %}}
    <p>No students found in {course}.</p>
    {{% endif %}}
</body>
</html>""")
        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
        finally:
            cursor.close()
            conn.close()
        return redirect('/')

    return render_template('add_student.html')

# ------------------------------
# EDIT STUDENT
# ------------------------------
@app.route("/edit/<int:id>", methods=["GET", "POST"])
def edit_student(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        first_name = request.form["first_name"]
        last_name = request.form["last_name"]
        email = request.form["email"]
        phone = request.form["phone"]
        course = request.form["course"]

        cursor.execute("""
            UPDATE students 
            SET first_name=%s, last_name=%s, email=%s, phone=%s, course=%s 
            WHERE id=%s
        """, (first_name, last_name, email, phone, course, id))
        conn.commit()
        flash("Student updated successfully!", "success")
        cursor.close()
        conn.close()
        return redirect(url_for("index"))

    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))
    student = cursor.fetchone()
    cursor.close()
    conn.close()
    if not student:
        flash("Student not found!", "danger")
        return redirect(url_for("index"))
    return render_template("edit_student.html", student=student)

# ------------------------------
# DELETE STUDENT
# ------------------------------
@app.route("/delete/<int:id>")
def delete_student(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE id=%s", (id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash("Student deleted successfully!", "success")
    return redirect(url_for("index"))

# ------------------------------
# VIEW COURSE PAGE WITH SEARCH
# ------------------------------
@app.route("/course/<course_name>")
def view_course(course_name):
    course_display_name = course_name.replace("_", " ")
    q = request.args.get("q", "").strip()

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if q and q.isdigit():
        cursor.execute("""
            SELECT * FROM students 
            WHERE course=%s AND id=%s
        """, (course_display_name, q))
    else:
        cursor.execute("SELECT * FROM students WHERE course=%s ORDER BY id DESC", (course_display_name,))
    students = cursor.fetchall()

    cursor.close()
    conn.close()

    template_path = f"{course_name}/index.html"
    return render_template(template_path, students=students, q=q, course_name=course_display_name)

# ------------------------------
if __name__ == "__main__":
    app.run(debug=True)
