function confirmDelete(name) {
    return confirm(`Are you sure you want to delete ${name}?`);
}
